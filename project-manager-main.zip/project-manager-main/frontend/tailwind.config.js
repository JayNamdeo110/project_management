module.exports = {
  content: [
    "./src/**.{html,js,jsx,ts,tsx,mdx}","./src/**.{html,js,jsx,ts,tsx,mdx}", // Add any additional file types as needed
,
  './components/**/*.{js,ts,jsx,tsx,mdx}',
  './src/components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
